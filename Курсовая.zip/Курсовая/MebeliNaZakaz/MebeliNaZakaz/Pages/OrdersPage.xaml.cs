﻿using MebeliNaZakaz.Entities;
using MebeliNaZakaz.Helpers;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MebeliNaZakaz.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrdersPage.xaml
    /// </summary>
    public partial class OrdersPage : Page
    {
        private bool _isMyOrders;

        public OrdersPage(bool isMyOrders)
        {
            InitializeComponent();
            _isMyOrders = isMyOrders;
            Loaded += OrdersPage_Loaded;
        }

        private void OrdersPage_Loaded(object sender, RoutedEventArgs e)
        {
            LoadOrders();
        }

        private void LoadOrders()
        {
            if (DgOrders == null)
            {
                Dispatcher.BeginInvoke(new Action(() => LoadOrders()));
                return;
            }
            try
            {
                if (CurrentUser.User == null)
                {
                    NavigationService.Navigate(new LoginPage());
                    return;
                }

                // Базовый запрос с загрузкой всех необходимых данных через Include
    var query = App.DB.Orders
     .Include("Users")
     .Include("OrderItems")
     .Include("OrderItems.FurnitureTypes")
     .Include("OrderItems.Materials")
     .AsQueryable();

                if (_isMyOrders)
                {
                    query = query.Where(o => o.UserID == CurrentUser.User.UserID);
                }

                // Фильтр по статусу
                if (CbStatusFilter?.SelectedItem is ComboBoxItem statusItem && statusItem.Content.ToString() != "Все")
                {
                    string status = statusItem.Content.ToString();
                    query = query.Where(o => o.Status == status);
                }

                // Поиск по номеру заказа
                if (TxtSearch != null && !string.IsNullOrWhiteSpace(TxtSearch.Text))
                {
                    if (int.TryParse(TxtSearch.Text, out int orderId))
                    {
                        query = query.Where(o => o.OrderID == orderId);
                    }
                }

                // Выполняем запрос и получаем список заказов
                var orders = query.OrderByDescending(o => o.OrderDate ?? DateTime.MinValue).ToList();

                // Теперь для каждого заказа вручную загружаем связанные данные, если они не загрузились автоматически
                foreach (var order in orders)
                {
                    if (order.OrderItems != null)
                    {
                        // Принудительно загружаем FurnitureType и Material для каждой позиции
                        foreach (var item in order.OrderItems)
                        {
                            if (item.FurnitureTypes == null && item.FurnitureTypeID != 0)
                            {
                                App.DB.Entry(item).Reference(i => i.FurnitureTypes).Load();
                            }
                            if (item.Materials == null && item.MaterialID != 0)
                            {
                                App.DB.Entry(item).Reference(i => i.Materials).Load();
                            }
                        }
                    }
                }

                // Формируем ViewModel для отображения
                var orderViewModels = new List<OrderViewModel>();
                foreach (var order in orders)
                {
                    string itemsDescription = "нет позиций";
                    if (order.OrderItems != null && order.OrderItems.Any())
                    {
                        var descriptions = new List<string>();
                        foreach (var oi in order.OrderItems)
                        {
                            string furnitureName = oi.FurnitureTypes?.Name ?? "Неизвестный тип";
                            descriptions.Add($"{furnitureName} ({oi.Quantity} шт)");
                        }
                        itemsDescription = string.Join(", ", descriptions);
                    }

                    orderViewModels.Add(new OrderViewModel
                    {
                        OrderID = order.OrderID,
                        OrderDate = order.OrderDate,
                        Status = order.Status,
                        TotalCost = order.TotalCost ?? 0,
                        DeliveryAddress = order.DeliveryAddress,
                        ItemsDescription = itemsDescription,
                        UserFullName = order.Users?.FullName ?? "Неизвестно"
                    });
                }

                if (DgOrders == null)
                {
                    MessageBox.Show("Ошибка: DataGrid не найден в XAML. Убедитесь, что x:Name=\"DgOrders\" задано.");
                    return;
                }

                DgOrders.ItemsSource = orderViewModels;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заказов: {ex.Message}\n{ex.StackTrace}");
            }
        }

        private void CbStatusFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadOrders();
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadOrders();
        }

        private void DgOrders_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (DgOrders.SelectedItem is OrderViewModel selected)
            {
                NavigationService.Navigate(new OrderDetailsPage(selected.OrderID));
            }
        }
    }

    // Класс для отображения в DataGrid
    public class OrderViewModel
    {
        public int OrderID { get; set; }
        public DateTime? OrderDate { get; set; }
        public string Status { get; set; }
        public decimal TotalCost { get; set; }
        public string DeliveryAddress { get; set; }
        public string ItemsDescription { get; set; } // краткое описание состава заказа
        public string UserFullName { get; set; }
    }
}
