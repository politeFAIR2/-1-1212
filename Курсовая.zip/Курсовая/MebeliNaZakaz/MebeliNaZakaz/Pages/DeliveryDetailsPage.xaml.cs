﻿using MebeliNaZakaz.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MebeliNaZakaz.Pages
{
    /// <summary>
    /// Логика взаимодействия для DeliveryDetailsPage.xaml
    /// </summary>
    public partial class DeliveryDetailsPage : Page
    {
        private int _deliveryId;
        private Deliveries _delivery;

        public DeliveryDetailsPage(int deliveryId)
        {
            InitializeComponent();
            _deliveryId = deliveryId;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDelivery();
        }

        private void LoadDelivery()
        {
            _delivery = App.DB.Deliveries.FirstOrDefault(d => d.DeliveryID == _deliveryId);
            if (_delivery == null)
            {
                MessageBox.Show("Доставка не найдена");
                NavigationService.GoBack();
                return;
            }

            TxtInfo.Text = $"Доставка заказа №{_delivery.OrderID} по адресу: {_delivery.DeliveryAddress}";
            // Установим текущий статус в ComboBox
            foreach (ComboBoxItem item in CbStatus.Items)
            {
                if (item.Content.ToString() == _delivery.Status)
                {
                    CbStatus.SelectedItem = item;
                    break;
                }
            }
        }

        private void BtnUpdateStatus_Click(object sender, RoutedEventArgs e)
        {
            if (CbStatus.SelectedItem == null) return;
            string newStatus = (CbStatus.SelectedItem as ComboBoxItem).Content.ToString();

            try
            {
                _delivery.Status = newStatus;
                if (newStatus == "Доставлен")
                {
                    _delivery.ActualDate = DateTime.Now;
                }
                App.DB.SaveChanges();
                MessageBox.Show("Статус обновлён");
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
