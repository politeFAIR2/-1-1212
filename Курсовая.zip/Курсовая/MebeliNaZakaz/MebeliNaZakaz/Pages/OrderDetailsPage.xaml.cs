﻿using MebeliNaZakaz.Entities;
using MebeliNaZakaz.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;
namespace MebeliNaZakaz.Pages
{
    public partial class OrderDetailsPage : Page
    {
        private int _orderId;
        private Orders _order;

        public bool IsManager => CurrentUser.IsManager;
        public bool IsClient => CurrentUser.IsClient;
        public bool IsCourier => CurrentUser.IsCourier;

        public OrderDetailsPage(int orderId)
        {
            InitializeComponent();
            _orderId = orderId;
            DataContext = this;
            System.Diagnostics.Debug.WriteLine($"OrderDetailsPage created with ID: {orderId}");
            Loaded += Page_Loaded;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            LoadOrder();
        }

        private void LoadOrder()
        {
            try
            {
               
    _order = App.DB.Orders
     .Include("Users")
     .Include("OrderItems")
     .Include("OrderItems.FurnitureTypes")
     .Include("OrderItems.Materials")
     .Include("Invoices")
     .Include("Deliveries")
     .Include("Deliveries.Users")
     .FirstOrDefault(o => o.OrderID == _orderId);

                if (_order == null)
                {
                    MessageBox.Show($"Заказ с номером {_orderId} не найден в базе данных.");
                    NavigationService.GoBack();
                    return;
                }

                // Заполнение основной информации
                TxtOrderId.Text = _order.OrderID.ToString();
                TxtOrderDate.Text = _order.OrderDate?.ToString("dd.MM.yyyy HH:mm") ?? "";
                TxtClient.Text = _order.Users?.FullName ?? "Неизвестно";
                TxtStatus.Text = _order.Status;
                TxtAddress.Text = _order.DeliveryAddress ?? "";
                TxtNotes.Text = _order.Notes ?? "";

                // Позиции заказа
                DgItems.ItemsSource = _order.OrderItems?.ToList() ?? new List<OrderItems>();

                // Счета
                DgInvoices.ItemsSource = _order.Invoices?.ToList() ?? new List<Invoices>();

                // Доставки
                DgDeliveries.ItemsSource = _order.Deliveries?.ToList() ?? new List<Deliveries>();

                // Список курьеров для менеджера
                if (CurrentUser.IsManager)
                {
                    CbCouriers.ItemsSource = App.DB.Users
                        .Where(u => u.RoleID == 3 && u.IsActive == true)
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}\n{ex.StackTrace}");
                NavigationService.GoBack();
            }
        }

        // Обработчики событий (без изменений, но с проверкой _order)
        private void BtnChangeStatus_Click(object sender, RoutedEventArgs e)
        {
            if (_order == null) { MessageBox.Show("Данные заказа не загружены"); return; }
            if (CbNewStatus.SelectedItem == null) return;
            string newStatus = (CbNewStatus.SelectedItem as ComboBoxItem)?.Content.ToString();

            try
            {
                _order.Status = newStatus;
                var history = new OrderStatusHistory
                {
                    OrderID = _order.OrderID,
                    Status = newStatus,
                    ChangedBy = CurrentUser.User.UserID
                };
                App.DB.OrderStatusHistory.Add(history);
                App.DB.SaveChanges();
                TxtStatus.Text = newStatus;
                MessageBox.Show("Статус обновлён");
            }
            catch (Exception ex) { MessageBox.Show($"Ошибка: {ex.Message}"); }
        }

        private void BtnPayInvoice_Click(object sender, RoutedEventArgs e)
        {
            if (_order == null) { MessageBox.Show("Данные заказа не загружены"); return; }
            var invoice = (sender as Button)?.Tag as Invoices;
            if (invoice == null) return;

            var result = MessageBox.Show($"Оплатить счёт №{invoice.InvoiceNumber} на сумму {invoice.Amount:N2} руб.?",
                                          "Подтверждение оплаты", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    invoice.Status = "Оплачен";
                    invoice.PaymentDate = DateTime.Now;
                    App.DB.SaveChanges();
                    MessageBox.Show("Счёт оплачен");
                    LoadOrder();
                }
                catch (Exception ex) { MessageBox.Show($"Ошибка: {ex.Message}"); }
            }
        }

        private void BtnAssignCourier_Click(object sender, RoutedEventArgs e)
        {
            if (_order == null) { MessageBox.Show("Данные заказа не загружены"); return; }
            if (CbCouriers.SelectedItem == null) { MessageBox.Show("Выберите курьера"); return; }

            var courier = CbCouriers.SelectedItem as Users;
            if (courier == null) return;

            try
            {
                var delivery = _order.Deliveries?.FirstOrDefault();
                if (delivery == null)
                {
                    delivery = new Deliveries
                    {
                        OrderID = _order.OrderID,
                        ScheduledDate = DateTime.Now.AddDays(2),
                        Status = "Запланирована",
                        DeliveryAddress = _order.DeliveryAddress
                    };
                    App.DB.Deliveries.Add(delivery);
                }

                delivery.CourierID = courier.UserID;
                App.DB.SaveChanges();
                MessageBox.Show("Курьер назначен");
                LoadOrder();
            }
            catch (Exception ex) { MessageBox.Show($"Ошибка: {ex.Message}"); }
        }

        private void BtnConfirmDelivery_Click(object sender, RoutedEventArgs e)
        {
            if (_order == null) { MessageBox.Show("Данные заказа не загружены"); return; }
            if (_order.Deliveries == null || !_order.Deliveries.Any())
            { MessageBox.Show("Доставка ещё не назначена"); return; }

            var delivery = _order.Deliveries.FirstOrDefault();
            if (delivery == null) return;

            if (delivery.Status != "Доставлен")
            { MessageBox.Show("Статус доставки ещё не 'Доставлен'"); return; }

            var result = MessageBox.Show("Подтвердить получение заказа?", "Подтверждение", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    delivery.ActualDate = DateTime.Now;
                    delivery.Status = "Выполнена";
                    _order.Status = "Доставлен";
                    App.DB.SaveChanges();
                    MessageBox.Show("Заказ получен. Спасибо!");
                    LoadOrder();
                }
                catch (Exception ex) { MessageBox.Show($"Ошибка: {ex.Message}"); }
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }

}