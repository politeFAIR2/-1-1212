﻿using MebeliNaZakaz.Entities;
using MebeliNaZakaz.Helpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MebeliNaZakaz.Pages
{
    /// <summary>
    /// Логика взаимодействия для CreateOrderPage.xaml
    /// </summary>
    public partial class CreateOrderPage : Page
    {
        private ObservableCollection<OrderItemViewModel> _items = new ObservableCollection<OrderItemViewModel>();
        private List<FurnitureTypes> _furnitureTypes;
        private List<Materials> _materials;

        // Свойство только для чтения (getter)
        public string UserAddress => CurrentUser.User?.Address ?? "";

        public CreateOrderPage()
        {
            InitializeComponent();
            DataContext = this;
            DgItems.ItemsSource = _items;
            _items.CollectionChanged += (s, e) => UpdateTotalCost();

            // Явно подписываемся на Loaded (на случай, если в XAML не прописано)
            this.Loaded += Page_Loaded;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                _furnitureTypes = App.DB.FurnitureTypes.ToList();
                _materials = App.DB.Materials.ToList();

                CbFurnitureType.ItemsSource = _furnitureTypes;
                CbMaterial.ItemsSource = _materials;

                if (_furnitureTypes.Any()) CbFurnitureType.SelectedIndex = 0;
                if (_materials.Any()) CbMaterial.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}");
            }
        }

        private void CbFurnitureType_SelectionChanged(object sender, SelectionChangedEventArgs e) { }

        private void BtnAddItem_Click(object sender, RoutedEventArgs e)
        {
            if (CbFurnitureType.SelectedItem == null || CbMaterial.SelectedItem == null)
            {
                MessageBox.Show("Выберите тип мебели и материал");
                return;
            }

            if (!decimal.TryParse(TxtWidth.Text, out decimal width) || width <= 0 ||
                !decimal.TryParse(TxtHeight.Text, out decimal height) || height <= 0 ||
                !decimal.TryParse(TxtDepth.Text, out decimal depth) || depth <= 0)
            {
                MessageBox.Show("Введите корректные положительные размеры (ширина, высота, глубина)");
                return;
            }

            if (!int.TryParse(TxtQuantity.Text, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Количество должно быть положительным целым числом");
                return;
            }

            var furnitureType = (FurnitureTypes)CbFurnitureType.SelectedItem;
            var material = (Materials)CbMaterial.SelectedItem; // явное приведение

            // Площадь одной стороны в м²
            decimal area = (width * height) / 10000m;

            // Если PricePerUnit nullable – используем GetValueOrDefault()
            decimal materialPrice = material.PricePerUnit; // если поле NOT NULL, то просто так
            // Если же оно nullable, раскомментируйте следующую строку и закомментируйте верхнюю:
            // decimal materialPrice = material.PricePerUnit.GetValueOrDefault();

            decimal unitPrice = furnitureType.BasePrice + materialPrice * area;

            var newItem = new OrderItemViewModel
            {
                FurnitureTypeID = furnitureType.TypeID,
                FurnitureTypeName = furnitureType.Name,
                MaterialID = material.MaterialID,
                MaterialName = material.Name,
                Width = width,
                Height = height,
                Depth = depth,
                Quantity = quantity,
                UnitPrice = Math.Round(unitPrice, 2)
            };

            _items.Add(newItem);
        }

        private void BtnRemoveItem_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as Button;
            var item = btn?.Tag as OrderItemViewModel;
            if (item != null)
                _items.Remove(item);
        }

        private void UpdateTotalCost()
        {
            decimal total = _items.Sum(i => i.TotalPrice);
            TxtTotalCost.Text = total.ToString("N2");
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtDeliveryAddress.Text))
            {
                MessageBox.Show("Введите адрес доставки");
                return;
            }

            if (_items.Count == 0)
            {
                MessageBox.Show("Добавьте хотя бы одну позицию");
                return;
            }

            try
            {
                var order = new Orders
                {
                    UserID = CurrentUser.User.UserID,
                    OrderDate = DateTime.Now,
                    Status = "Новый",
                    DeliveryAddress = TxtDeliveryAddress.Text,
                    Notes = TxtNotes.Text,
                    TotalCost = _items.Sum(i => i.TotalPrice)
                };
                App.DB.Orders.Add(order);
                App.DB.SaveChanges();

                foreach (var item in _items)
                {
                    var orderItem = new OrderItems
                    {
                        OrderID = order.OrderID,
                        FurnitureTypeID = item.FurnitureTypeID,
                        MaterialID = item.MaterialID,
                        Width = item.Width,
                        Height = item.Height,
                        Depth = item.Depth,
                        Quantity = item.Quantity,
                        UnitPrice = item.UnitPrice
                    };
                    App.DB.OrderItems.Add(orderItem);
                }
                App.DB.SaveChanges();

                // Создание счёта на предоплату (50%)
                var invoice = new Invoices
                {
                    OrderID = order.OrderID,
                    InvoiceNumber = $"INV-{DateTime.Now:yyyyMMdd}-{order.OrderID}",
                    Amount = (order.TotalCost ?? 0) * 0.5m,
                    InvoiceType = "Предоплата",
                    Status = "Ожидает",
                    DueDate = DateTime.Now.AddDays(7)
                };
                App.DB.Invoices.Add(invoice);
                App.DB.SaveChanges();

                // История статуса
                var history = new OrderStatusHistory
                {
                    OrderID = order.OrderID,
                    Status = order.Status,
                    ChangedBy = CurrentUser.User.UserID
                };
                App.DB.OrderStatusHistory.Add(history);
                App.DB.SaveChanges();

                MessageBox.Show($"Заказ №{order.OrderID} успешно создан.\nНеобходимо внести предоплату 50% ({invoice.Amount:N2} руб.)",
                                "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении заказа: {ex.Message}");
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }

    public class OrderItemViewModel
    {
        public int FurnitureTypeID { get; set; }
        public string FurnitureTypeName { get; set; }
        public int MaterialID { get; set; }
        public string MaterialName { get; set; }
        public decimal Width { get; set; }
        public decimal Height { get; set; }
        public decimal Depth { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal TotalPrice => Quantity * UnitPrice;
    }
}
