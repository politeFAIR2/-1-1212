﻿using MebeliNaZakaz.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MebeliNaZakaz.Pages
{
    /// <summary>
    /// Логика взаимодействия для MainMenuPage.xaml
    /// </summary>
    public partial class MainMenuPage : Page
    {
        // Свойства для привязки
        public string CurrentUserName => CurrentUser.User?.FullName ?? "Гость";
        public bool IsManager => CurrentUser.IsManager;
        public bool IsCourier => CurrentUser.IsCourier;
        public bool IsClient => CurrentUser.IsClient;
        public MainMenuPage()
        {
            InitializeComponent();
            DataContext = this; // связываем XAML с этой страницей
        }

        private void MyOrders_Click(object sender, System.Windows.RoutedEventArgs e)
            => NavigationService?.Navigate(new OrdersPage(true));

        private void NewOrder_Click(object sender, System.Windows.RoutedEventArgs e)
            => NavigationService?.Navigate(new CreateOrderPage());

        private void AllOrders_Click(object sender, System.Windows.RoutedEventArgs e)
            => NavigationService?.Navigate(new OrdersPage(false));

        private void Deliveries_Click(object sender, System.Windows.RoutedEventArgs e)
            => NavigationService?.Navigate(new DeliveriesPage(false));

        private void CourierDeliveries_Click(object sender, System.Windows.RoutedEventArgs e)
            => NavigationService?.Navigate(new DeliveriesPage(true));

        private void Reports_Click(object sender, System.Windows.RoutedEventArgs e)
            => NavigationService?.Navigate(new ReportsPage());

        private void BtnLogout_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            CurrentUser.User = null;
            NavigationService?.Navigate(new LoginPage());
        }
    }
}
