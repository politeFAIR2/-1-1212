﻿using MebeliNaZakaz.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MebeliNaZakaz.Entities;
namespace MebeliNaZakaz.Pages
{
    /// <summary>
    /// Логика взаимодействия для DeliveriesPage.xaml
    /// </summary>
   public partial class DeliveriesPage : Page
    {
        public DeliveriesPage(bool v)
        {
            InitializeComponent();
            Loaded += DeliveriesPage_Loaded;
        }

        private void DeliveriesPage_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDeliveries();
        }

        private void LoadDeliveries()
        {
            try
            {
                var deliveries = App.DB.Deliveries
                    .Include("Courier")
                    .Include("Order")
                    .ToList();

                // Если это курьер — показываем только его доставки
                if (CurrentUser.IsCourier)
                {
                    deliveries = deliveries
                        .Where(d => d.CourierID == CurrentUser.User.UserID)
                        .ToList();
                }

                DgDeliveries.ItemsSource = deliveries;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки доставок: " + ex.Message);
            }
        }

        private void DgDeliveries_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (DgDeliveries.SelectedItem is Deliveries delivery)
            {
                NavigationService.Navigate(new DeliveryDetailsPage(delivery.DeliveryID));
            }
        }

        private void DgDeliveries_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
