﻿using MebeliNaZakaz.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MebeliNaZakaz.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Properties.Settings.Default.RememberMe)
            {
                TxtLogin.Text = Properties.Settings.Default.LastLogin;
                PwdPassword.Password = Properties.Settings.Default.LastPassword;
                ChkRemember.IsChecked = true;
            }
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = TxtLogin.Text.Trim();
            string password = PwdPassword.Password.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                ShowError("Введите логин и пароль");
                return;
            }

            try
            {
                var user = App.DB.Users
                    .FirstOrDefault(u => u.Login == login && u.PasswordHash == password && u.IsActive == true);

                if (user != null)
                {
                    CurrentUser.User = user;
                    user.LastLoginDate = DateTime.Now;
                    App.DB.SaveChanges();

                    // Сохраняем настройки
                    Properties.Settings.Default.LastLogin = login;
                    Properties.Settings.Default.LastPassword = ChkRemember.IsChecked == true ? password : "";
                    Properties.Settings.Default.RememberMe = ChkRemember.IsChecked == true;
                    Properties.Settings.Default.Save();

                    NavigationService.Navigate(new MainMenuPage());
                }
                else
                {
                    ShowError("Неверный логин или пароль");
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка подключения: {ex.Message}");
            }
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new RegisterPage());
        }

        private void ShowError(string message)
        {
            TxtError.Text = message;
            TxtError.Visibility = Visibility.Visible;
        }
    }
}
