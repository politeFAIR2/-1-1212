﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MebeliNaZakaz.Entities;
namespace MebeliNaZakaz.Pages
{
    /// <summary>
    /// Логика взаимодействия для RegisterPage.xaml
    /// </summary>
    public partial class RegisterPage : Page
    {
        public RegisterPage()
        {
            InitializeComponent();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            string fullName = TxtFullName.Text.Trim();
            string phone = TxtPhone.Text.Trim();
            string address = TxtAddress.Text.Trim();
            string login = TxtLogin.Text.Trim();
            string password = PwdPassword.Password.Trim();
            string confirm = PwdConfirm.Password.Trim();

            // Валидация
            if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(phone) || string.IsNullOrEmpty(login) ||
                string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirm))
            {
                ShowError("Заполните все поля");
                return;
            }

            if (password != confirm)
            {
                ShowError("Пароли не совпадают");
                return;
            }

            if (password.Length < 3)
            {
                ShowError("Пароль должен быть не менее 3 символов");
                return;
            }

            // Проверка телефона (простая)
            if (!Regex.IsMatch(phone, @"^\+?\d{10,15}$"))
            {
                ShowError("Введите корректный номер телефона");
                return;
            }

            try
            {
                // Проверка уникальности логина
                if (App.DB.Users.Any(u => u.Login == login))
                {
                    ShowError("Пользователь с таким логином уже существует");
                    return;
                }

                // Создание пользователя
                var user = new Users
                {
                    Login = login,
                    PasswordHash = password, // В реальном проекте нужно хешировать
                    FullName = fullName,
                    Phone = phone,
                    Address = address,
                    RoleID = 1, // Клиент
                    RegistrationDate = DateTime.Now,
                    IsActive = true
                };
                App.DB.Users.Add(user);
                App.DB.SaveChanges();

                MessageBox.Show("Регистрация успешна! Теперь вы можете войти.", "Успех",
                                MessageBoxButton.OK, MessageBoxImage.Information);
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка: {ex.Message}");
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void ShowError(string message)
        {
            TxtError.Text = message;
            TxtError.Visibility = Visibility.Visible;
        }
    }
}
