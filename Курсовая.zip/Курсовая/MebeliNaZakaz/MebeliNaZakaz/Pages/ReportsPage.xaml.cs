﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MebeliNaZakaz.Pages
{
    /// <summary>
    /// Логика взаимодействия для ReportsPage.xaml
    /// </summary>
    public partial class ReportsPage : Page
    {
        public ReportsPage()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            // Устанавливаем начальные даты: начало предыдущего месяца и сегодня
            DpStart.SelectedDate = DateTime.Now.AddMonths(-1).Date;
            DpEnd.SelectedDate = DateTime.Now.Date;
        }

        private void BtnGenerate_Click(object sender, RoutedEventArgs e)
        {
            if (DpStart.SelectedDate == null || DpEnd.SelectedDate == null)
            {
                MessageBox.Show("Выберите период");
                return;
            }

            DateTime start = DpStart.SelectedDate.Value.Date;
            DateTime end = DpEnd.SelectedDate.Value.Date.AddDays(1).AddSeconds(-1);

            try
            {
                var orders = App.DB.Orders
                    .Where(o => o.OrderDate >= start && o.OrderDate <= end)
                    .Select(o => new
                    {
                        o.OrderID,
                        o.OrderDate,
                        o.Users.FullName,
                        o.Users.Phone,
                        o.TotalCost,
                        o.Status,
                        o.DeliveryAddress
                    })
                    .ToList();

                DgReport.ItemsSource = orders;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
    }
}
