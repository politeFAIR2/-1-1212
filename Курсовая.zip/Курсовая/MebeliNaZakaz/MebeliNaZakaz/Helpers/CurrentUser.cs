﻿using MebeliNaZakaz.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MebeliNaZakaz.Helpers
{
    public static class CurrentUser
    {
        public static Users User { get; set; }
        public static bool IsAuthenticated => User != null;
        public static bool IsClient => User?.RoleID == 1;
        public static bool IsManager => User?.RoleID == 2;
        public static bool IsCourier => User?.RoleID == 3;
    }
}
