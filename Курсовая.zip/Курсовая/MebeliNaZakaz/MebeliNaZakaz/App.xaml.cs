﻿using MebeliNaZakaz.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace MebeliNaZakaz
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static MebeliNaZakazDBEntities DB = new MebeliNaZakazDBEntities();
    }
}
